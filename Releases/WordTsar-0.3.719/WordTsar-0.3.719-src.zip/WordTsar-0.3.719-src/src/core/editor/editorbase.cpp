#include "editorbase.h"

cEditorBase::cEditorBase()
{
}
