The basis for this reader is DuckX  https://github.com/amiremohamadi/DuckX


