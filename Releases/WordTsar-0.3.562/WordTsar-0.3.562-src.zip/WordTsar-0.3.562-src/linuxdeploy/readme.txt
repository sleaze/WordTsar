Linux deployment to AppImage

1. Download linuxdeploy-x86_64.AppImage from https://github.com/linuxdeploy/linuxdeploy/releases/
2. Download linuxdeploy-plugin-qt-x86_64.AppImage from https://github.com/linuxdeploy/linuxdeploy-plugin-qt/releases
3. Move both to /usr/local/bin and make them executable
4. Run the linuxdeploy.sh script in this directory

You will now have a WordTsar-x86_64.AppImage file. Make sure it's executable, and away you go.

