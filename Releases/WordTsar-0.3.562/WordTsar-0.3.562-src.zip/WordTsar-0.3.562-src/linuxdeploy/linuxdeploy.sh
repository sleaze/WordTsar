#!/bin/bash
linuxdeploy-x86_64.AppImage --appdir WordTsar --executable=/home/gbr/src/build-wordtsar-Desktop_Qt_5_15_2_GCC_64bit-Release/WordTsar --desktop-file=WordTsar.desktop --icon-file=wordtsar.png --plugin=qt --output=appimage
